#!/usr/bin/env python
import setuptools

setuptools.setup(
    setup_requires=['pbr>=1.3', 'setuptools>=17.1'],
    pbr=True)
